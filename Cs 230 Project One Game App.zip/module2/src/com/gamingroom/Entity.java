package com.gamingroom;

public class Entity {

	protected long id;
	
	protected String name;
	
	protected Entity() {}
	// ^ So that game, team, and player can all access Entity's constructor
	
	public Entity(long id, String name) { // Constructor
		this.id = id;
		this.name = name;
	}
	
	// Processes for returning Ids and names
	public long getId() {
		return id;
	}
	
	public String getName() {
		return name;
	}
	
	
	public String toString() {
		return "Entity [id = " + id + ", name = " + name + "]";
	}
	
}
